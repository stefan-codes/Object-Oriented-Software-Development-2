﻿using System;

namespace BusinessLayer
{
    public class Class1
    {
    }
}
