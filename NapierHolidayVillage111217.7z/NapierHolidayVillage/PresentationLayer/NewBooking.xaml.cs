﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentationLayer
{
    /// <summary>
    /// Interaction logic for NewBooking.xaml
    /// </summary>
    public partial class NewBooking : Window
    {
        public NewBooking()
        {
            InitializeComponent();
            this.DisableNewCustomerInfo();
            this.UpdateChalets();
        }


        //Closes the window without saving any of the details
        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        //Disable all fields for a new customer
        private void DisableNewCustomerInfo()
        {
            NewCustomerNameTxt.IsEnabled = false;
            NewCustomerNameLbl.IsEnabled = false;
            NewCustomerAddressTxt.IsEnabled = false;
            NewCustomerAddressLbl.IsEnabled = false;
            CustomerIDTxt.IsEnabled = true;
        }

        //Enable all fields for a new customer
        private void EnableNewCustomerInfo()
        {
            NewCustomerNameTxt.IsEnabled = true;
            NewCustomerNameLbl.IsEnabled = true;
            NewCustomerAddressTxt.IsEnabled = true;
            NewCustomerAddressLbl.IsEnabled = true;
            CustomerIDTxt.Text = "";
            CustomerIDTxt.IsEnabled = false;
        }

        //If the New Customer is checked - Enable all fields
        private void NewCustomerChBx_Checked(object sender, RoutedEventArgs e)
        {
            this.EnableNewCustomerInfo();
        }

        //If the New Customer is unchecked - Diasble all fields
        private void NewCustomerChBx_Unchecked(object sender, RoutedEventArgs e)
        {
            this.DisableNewCustomerInfo();
        }

        //When the value of the slider is changed update the label as well
        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            NumberOfGuestsSelectedLbl.Content = NumberOfGuestsSld.Value;
        }

        //Load avaliable chalets into the drop down menu
        private void UpdateChalets()
        {
            //get which chalets are empty acording to the period selected
            //Assume we get 10 right now
            List<int> numFree = new List<int>();

            //do it here
            numFree.Add(1);
            numFree.Add(2);
            numFree.Add(3);
            numFree.Add(5);
            numFree.Add(8);
            numFree.Add(10);

            foreach (int num in numFree)
            {
                ComboBoxItem hut = new ComboBoxItem();
                hut.Content = num;
                dropDown.Items.Add(hut);
            }

        }





    }
}
