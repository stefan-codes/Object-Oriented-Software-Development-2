﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NewBookingBtn_Click(object sender, RoutedEventArgs e)
        {
            NewBooking bookingWin = new NewBooking();
            bookingWin.Show();
        }

        private void NewCustomerBtn_Click(object sender, RoutedEventArgs e)
        {
            NewCustomer customerWin = new NewCustomer();
            customerWin.Show();
        }

        private void ExitBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void FindCustomerBtn_Click(object sender, RoutedEventArgs e)
        {
            FindCustomer findCustomerW = new FindCustomer();
            findCustomerW.Show();
        }
    }
}
