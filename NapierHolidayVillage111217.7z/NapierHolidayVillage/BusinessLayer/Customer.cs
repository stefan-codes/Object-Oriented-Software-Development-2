﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer;

namespace BusinessLayer
{
    public class Customer
    {
        //Create a New Customer, Add to the List of Customers and List of UsedIDs
        public static void Create(string name, string address)
        {
            int newID = IDsFactory.GenerateID.Generate("customer").IDnumber();
            DataLayer.Customer customer = new DataLayer.Customer(name, address, newID);
            CustomersSingleton.Instance.AddCustomer(customer);
            CustomersSingleton.Instance.AddUsedID(newID);
        }

        //Find a Customer, return results acording to matches. IF all fields are empty return all.
        public static List<DataLayer.Customer> Find(int id=0, string name ="", string address ="")
        {
            List<DataLayer.Customer> customer = new List<DataLayer.Customer>();
            if (id != 0)
            {
                try
                {
                    customer.Add(CustomersSingleton.Instance.Customers.Find(c => c.ID == id));
                }
                catch(Exception idExep)
                {
                    throw new Exception(idExep.Message);
                }
            } else {
                if (!name.Equals(""))
                {
                    //if the name is not empty
                    if (!address.Equals(""))
                    {
                        //if the address is not empty
                        try
                        {
                            customer.Add(CustomersSingleton.Instance.Customers.Find(c => c.Name.Equals(name) && c.Address.Equals(address)));
                        }
                        catch (Exception nameAddressExep)
                        {
                            throw new Exception(nameAddressExep.Message);
                        } 
                    }
                    else
                    {
                        //if the address is empty
                        try
                        {
                            customer.Add(CustomersSingleton.Instance.Customers.Find(c => c.Name.Equals(name)));
                        }
                        catch (Exception nameExep)
                        {
                            throw new Exception(nameExep.Message);
                        }
                    }
                } else
                {
                    //if the name is empty
                    if (!address.Equals(address))
                    {
                        //if the address is not empty
                        try
                        {
                            customer.Add(CustomersSingleton.Instance.Customers.Find(c => c.Address.Equals(address)));
                        }
                        catch (Exception addressExep)
                        {
                            throw new Exception(addressExep.Message);
                        }
                    } else
                    {
                        //if the address is empty aka all filds are empty
                        try
                        {
                            customer = CustomersSingleton.Instance.Customers;
                        }
                        catch (Exception badExep)
                        {
                            throw new Exception("something went side ways :/   " + badExep.Message);
                        }
                    }
                }
            }
            return customer;
        }

        //Delete a Customer by removing it from the Singleton Customers.
        public static void Delete(int id)
        {
            foreach(DataLayer.Customer c in Find(id))
            {
                CustomersSingleton.Instance.Customers.Remove(c);
            }
        }

        
    }
}
