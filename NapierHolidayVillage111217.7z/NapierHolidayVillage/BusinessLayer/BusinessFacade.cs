﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessLayer
{
    public static class BusinessFacade
    {
        //Create a new Customer
        public static void CreateCustomer(string name, string address)
        {
            Customer.Create(name, address);
        }

        //Find a Customer by using their ID
        public static void FindCustomerID(int id=0, string name="", string address="")
        {
            Customer.Find(id, name, address);
        }

        //Delete a Customer
        public static void DeleteCustomer(int id)
        {
            Customer.Delete(id);
        }
    }
}
