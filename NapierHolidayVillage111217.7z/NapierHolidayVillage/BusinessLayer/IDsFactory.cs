﻿using System;
using System.Collections.Generic;
using System.Text;
using DataLayer;
using System.Linq;

namespace BusinessLayer
{
    class IDsFactory
    {
        public interface ID
        {
            int IDnumber();
        }

        class CustomerID : ID
        {
            public int IDnumber()
            {
                int i=0;
                if (CustomersSingleton.Instance.UsedIDs.Any())
                {
                    i = CustomersSingleton.Instance.UsedIDs.Last() + 1;
                } else
                {
                    i = 1;
                }
                return i;
            }
        }

        class BookingID : ID
        {
            public int IDnumber()
            {

                return 0;
            }

        }

        class ChaletID : ID
        {
            public int IDnumber()
            {

                return 0;
            }
        }

         public class GenerateID
        {
            public static ID Generate(string str)
            {
                if (str.Equals("bookingID"))
                {
                    return new BookingID();
                } else if (str.Equals("customerID"))
                {
                    return new CustomerID();
                } else if (str.Equals("chaletID"))
                {
                    return new ChaletID();
                } else
                {
                    throw new Exception("Wrong string for type of ID to generate!");
                }
            } 
        } 
    }
}
