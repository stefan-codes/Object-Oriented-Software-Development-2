﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class Guest
    {
        private string _name;
        private string _passNumb;
        private int _age;

        //Constructor enforces name, passport number and age
        public Guest(string name, string passNumb, int age)
        {
            _name = name;
            _passNumb = passNumb;
            _age = age;
        }

        //Getter and Setter for _age
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        //Getter and Setter for _name
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        //Getter and Setter for _passNumb
        public string PassportNumber
        {
            get { return _passNumb; }
            set { _passNumb = value; }
        }
    }
}
