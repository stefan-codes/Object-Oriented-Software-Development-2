﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class Chalet
    {
        private int _id;
        private bool _available;

        //Constructor enforces id and avaliable status
        public Chalet(int id, bool available)
        {
            _id = id;
            _available = available;
        }

        //Getter and Setter for _id
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        //Getter and Setter for _avaliable
        public bool Avaliable
        {
            get { return _available; }
            set { _available = value; }
        }
    }
}
