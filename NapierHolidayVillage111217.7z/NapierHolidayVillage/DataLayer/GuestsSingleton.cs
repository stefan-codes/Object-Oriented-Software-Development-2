﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class GuestsSingleton
    {
        private static GuestsSingleton instance;
        List<Guest> Guests = new List<Guest>();

        //Private constructor
        private GuestsSingleton()
        {

        }

        public static GuestsSingleton Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new GuestsSingleton();
                }
                return instance;
            }
        }
    }
}
