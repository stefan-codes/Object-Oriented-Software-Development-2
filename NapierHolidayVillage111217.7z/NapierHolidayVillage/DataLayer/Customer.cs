﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class Customer
    {
        private string _name;
        private string _address;
        private int _id;
        private List<Booking> _bookings = new List<Booking>();

        //Constructor which enforces name, address and ID 
        public Customer(string name, string address, int ID)
        {
            _name = name;
            _address = address;
            _id = ID;
        }

        //getter and setter for _name
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        //getter and setter for _address
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        //getter and setter for _id
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        //getter for _bookings
        public List<Booking> Bookings
        {
            get { return _bookings; }
        }

        //Add booking to the customer
        public void AddBooking(Booking b)
        {
            _bookings.Add(b);
        }

        //Remove booking from the customer
        public void RemoveBooking(Booking b)
        {
            _bookings.Remove(b);
        }




    }
}
