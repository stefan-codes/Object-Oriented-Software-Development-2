﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class BookingsSingleton
    {
        private static BookingsSingleton instance;
        List<Booking> Bookings = new List<Booking>();

        //Private constructor
        private BookingsSingleton()
        {

        }

        public static BookingsSingleton Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new BookingsSingleton();
                }
                return instance;
            }
        }
    }
}
