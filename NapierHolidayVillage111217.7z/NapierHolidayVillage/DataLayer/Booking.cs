﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer
{
    public class Booking
    {
        private int _id;
        private DateTime _arrivalDate;
        private DateTime _departureDate;
        private int _chaletId;

        //Constructor enforcing id, arrival date, departure Date and chalet ID
        public Booking(int id, DateTime adate, DateTime ddate, int chID)
        {
            _id = id;
            _arrivalDate = adate;
            _departureDate = ddate;
            _chaletId = chID;
        }

        //Getter and Setter for _id
        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        //Getter and Setter for _arrivalDate
        public DateTime ArrivalDate
        {
            get { return _arrivalDate; }
            set { _arrivalDate = value; }
        }

        //Getter and Setter for _departureDate
        public DateTime DepartureDate
        {
            get { return _departureDate; }
            set { _departureDate = value; }
        }

        //Getter and Setter for _chaletId
        public int ChaletID
        {
            get { return _chaletId; }
            set { _chaletId = value; }
        }
    }
}
