﻿using System;
using System.Collections.Generic;

namespace DataLayer
{
    public class CustomersSingleton
    {
        private static CustomersSingleton instance;
        private List<Customer> _customers = new List<Customer>();
        private List<int> _usedIDs = new List<int>();

        //Private constructor
        private CustomersSingleton()
        {
           
        }

        public static CustomersSingleton Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CustomersSingleton();
                }
                return instance;
            }
        }

        //Getter and Setter for Customers list
        public List<Customer> Customers
        {
            get { return _customers; }
            set { _customers = value; }
        }

        //Adds a customer to the list _customers
        public void AddCustomer(Customer c)
        {
            _customers.Add(c);
        }

        //Getter and Setter for UsedIDs list
        public List<int> UsedIDs
        {
            get { return _usedIDs; }
            set { _usedIDs = value; }
        }

        //Adds a customer id to the list _usedIDs
        public void AddUsedID(int i)
        {
            _usedIDs.Add(i);
        }

        //Delete a Customer
        public void DeleteCustomer(Customer c)
        {
            _customers.Remove(c);
        }

        //Delete a Used ID
        public void DeleteUsedID(int id)
        {
            _usedIDs.Remove(id);
        }




    }
}
